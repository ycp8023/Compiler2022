package frontend.ast;

public class Pair {
    public String parent;
    public String child;

}
