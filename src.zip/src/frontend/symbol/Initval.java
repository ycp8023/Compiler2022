package frontend.symbol;

import java.util.ArrayList;

public class Initval {
    public int initval;
    public ArrayList<Integer> initvals;
    public Initval(int initval){
        this.initval=initval;
    }
    public Initval(ArrayList<Integer> initvals){
        this.initvals=initvals;
    }
}
