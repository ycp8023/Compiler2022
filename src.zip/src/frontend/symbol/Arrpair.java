package frontend.symbol;

public class Arrpair {
    public int x;
    public int y;
    public Arrpair(int x, int y){
        this.x=x;
        this.y=y;
    }
    public Arrpair(int x){
        this.x=x;
    }
}
