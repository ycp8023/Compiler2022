package middle.expcal;

public class Pair {
    public int num;     //第几个变量
    public int val;     //变量值
    public Pair(int val,int num) {
        this.num=num;
        this.val=val;
    }
}
